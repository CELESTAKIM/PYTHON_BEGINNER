from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, flash
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = 'supersecretkey'
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# In-memory stores
users = {}
admin_passcodes = {}

@app.route('/', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        username = request.form['username']
        nationality = request.form['nationality']
        postcode = request.form['postcode']
        city = request.form['city']
        town = request.form['town']
        password = generate_password_hash(request.form['password'])

        profile_img = request.files['profile_image']
        img_filename = secure_filename(profile_img.filename)
        profile_img.save(os.path.join(app.config['UPLOAD_FOLDER'], img_filename))

        users[username] = {
            'name': name,
            'email': email,
            'phone': phone,
            'username': username,
            'profile_image': img_filename,
            'nationality': nationality,
            'postcode': postcode,
            'city': city,
            'town': town,
            'password': password
        }

        session['username'] = username
        return redirect(url_for('welcome'))

    return render_template('register.html')

@app.route('/welcome')
def welcome():
    if 'username' not in session:
        return redirect(url_for('register'))
    return render_template('welcome.html')

@app.route('/view-profile')
def view_profile():
    username = session.get('username')
    if not username or username not in users:
        return redirect(url_for('register'))
    return render_template('profile.html', user=users[username])

@app.route('/edit-profile', methods=['GET', 'POST'])
def edit_profile():
    username = session.get('username')
    if not username or username not in users:
        return redirect(url_for('register'))
    if request.method == 'POST':
        users[username]['phone'] = request.form['phone']
        users[username]['password'] = generate_password_hash(request.form['password'])
        return redirect(url_for('view_profile'))
    return render_template('edit.html', user=users[username])

@app.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        entered_passcode = request.form['admin_passcode']
        for user in users.values():
            expected_passcode = f"ASDFGHJKL@{user['username']}"
            if entered_passcode == expected_passcode:
                session['admin'] = True
                return redirect(url_for('admin_dashboard'))
        flash("Invalid passcode.")
    return render_template('admin_login.html')

@app.route('/admin-dashboard')
def admin_dashboard():
    if not session.get('admin'):
        return redirect(url_for('admin_login'))
    return render_template('admin_dashboard.html', users=users)

@app.route('/admin/delete/<username>')
def delete_user(username):
    if session.get('admin') and username in users:
        del users[username]
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/add', methods=['GET', 'POST'])
def add_user():
    if not session.get('admin'):
        return redirect(url_for('admin_login'))
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        username = request.form['username']
        nationality = request.form['nationality']
        postcode = request.form['postcode']
        city = request.form['city']
        town = request.form['town']
        password = generate_password_hash(request.form['password'])

        profile_img = request.files['profile_image']
        img_filename = secure_filename(profile_img.filename)
        profile_img.save(os.path.join(app.config['UPLOAD_FOLDER'], img_filename))

        users[username] = {
            'name': name,
            'email': email,
            'phone': phone,
            'username': username,
            'profile_image': img_filename,
            'nationality': nationality,
            'postcode': postcode,
            'city': city,
            'town': town,
            'password': password
        }
        return redirect(url_for('admin_dashboard'))
    return render_template('admin_add.html')