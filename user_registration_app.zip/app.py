from flask import Flask, render_template, request, redirect, url_for, session
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# In-memory user store (in real life, use a database)
users = {}

@app.route('/', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        github = request.form['github']
        linkedin = request.form['linkedin']
        social_media = request.form.getlist('social_media')
        profile_image = request.form['profile_image']
        nationality = request.form['nationality']
        postcode = request.form['postcode']
        city = request.form['city']
        town = request.form['town']
        password = generate_password_hash(request.form['password'])

        users[email] = {
            'name': name,
            'email': email,
            'phone': phone,
            'github': github,
            'linkedin': linkedin,
            'social_media': social_media,
            'profile_image': profile_image,
            'nationality': nationality,
            'postcode': postcode,
            'city': city,
            'town': town,
            'password': password
        }
        session['email'] = email
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    email = session.get('email')
    if not email or email not in users:
        return redirect(url_for('register'))
    return render_template('dashboard.html', user=users[email])

@app.route('/edit', methods=['GET', 'POST'])
def edit():
    email = session.get('email')
    if not email or email not in users:
        return redirect(url_for('register'))
    if request.method == 'POST':
        users[email]['phone'] = request.form['phone']
        users[email]['password'] = generate_password_hash(request.form['password'])
        return redirect(url_for('dashboard'))
    return render_template('edit.html', user=users[email])

if __name__ == '__main__':
    app.run(debug=True)